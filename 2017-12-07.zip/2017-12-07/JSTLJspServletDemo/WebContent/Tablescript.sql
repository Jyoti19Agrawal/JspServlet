CREATE TABLE courses(courseId number(4) PRIMARY KEY,courseName varchar2(15)
 NOT NULL, courseDuration number(3) NOT NULL);

 
