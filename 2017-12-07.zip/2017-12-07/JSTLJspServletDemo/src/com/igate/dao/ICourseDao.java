package com.igate.dao;

import java.util.ArrayList;

import com.igate.dto.Course;
import com.igate.exception.CourseException;

public interface ICourseDao {
	
	public boolean addcourse(Course course) throws CourseException;
	public ArrayList<Course> retrieveAllcourse() throws CourseException;
	public Course retrieveCourse(int eid) throws CourseException;
}
