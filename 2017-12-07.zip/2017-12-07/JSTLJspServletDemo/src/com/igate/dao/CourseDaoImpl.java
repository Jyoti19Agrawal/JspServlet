package com.igate.dao;

/* Table Creation in database
 * CREATE table Course(
 * courseId NUMBER(6) PRIMARY KEY,
 * courseName VARCHAR2(30),
 * courseDuration NUMBER(5)
 * );
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.igate.dto.Course;
import com.igate.exception.CourseException;

public class CourseDaoImpl implements ICourseDao {

	Connection connection = null;
	Statement statement = null;
	ResultSet rsSet = null;
	PreparedStatement preparedStatement = null;

	public Course retrieveCourse(int cid) {
		Course course = null;
		System.out.println("In dao " + cid);

		String qry = "select courseId ,courseName, courseDuration from Courses where courseId=?";
		PreparedStatement pstmt;
		try {
			pstmt = connection.prepareStatement(qry);
			pstmt.setInt(1, cid);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				course = new Course();
				course.setCourseId(rs.getInt("courseId"));
				course.setCourseName(rs.getString("courseName"));
				course.setCourseDuration(rs.getInt(3));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return course;
	}

	@Override
	public boolean addcourse(Course course) throws CourseException {

		int insertSuccess = 0;
		String insQry = "insert into Courses values(?,?,?)";
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(insQry);
			pst.setInt(1, course.getCourseId());
			pst.setString(2, course.getCourseName());
			pst.setDouble(3, course.getCourseDuration());
			insertSuccess = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (insertSuccess > 0)
			return true;
		else
			return false;
	}

	@Override
	public ArrayList<Course> retrieveAllcourse() throws CourseException {
		ArrayList<Course> cList = new ArrayList<Course>();

		String qry = "select courseId,courseName,courseDuration from Courses";
		Statement stmt;
		try {
			stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while (rs.next()) {
				Course course = new Course();
				course.setCourseId(rs.getInt(1));
				course.setCourseName(rs.getString(2));
				course.setCourseDuration(rs.getInt(3));
				cList.add(course);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return cList;
	}

	public int deleteCourseById(int id) throws CourseException {

		int id1 = 0;
		String sql = "DELETE FROM courses WHERE courseId=?";
		try {
			Course course = new Course();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, course.getCourseId());
			id1 = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			throw new CourseException("Error while deleting values::"
					+ e.getMessage());
		}
		return id1;
	}

}
